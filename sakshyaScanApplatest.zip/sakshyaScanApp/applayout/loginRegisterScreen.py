from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
import kivy.utils as utils
from kivy.animation import Animation
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.textfield import MDTextField
from kivy.metrics import dp


MS = """
<MyScreen>:
    ScreenLayout:
"""

SL = """
#: import utils kivy.utils

<ScreenLayout>:
    canvas.before:
        Color:
            rgba: utils.get_color_from_hex('F1E5D1')
        RoundedRectangle:
            # source: 'assets/loginBackground.jpeg'
            size: self.size
            pos: self.pos
            # radius: [cm(0.5), cm(0.5), cm(0.5), cm(0.5)]  # Adjust radius for rounded corners

    MDGridLayout:
        cols: 2
        spacing: 30
        padding: 30
        MDBoxLayout:
            orientation: 'vertical'
            canvas.before:
                Color:
                    rgba: 1, 0.7, 1, 1  # White background - others create an overlay effect over BorderImage
                RoundedRectangle:
                    source: 'assets/loginBackground.jpeg'
                    size: self.size
                    pos: self.pos
                    radius: [cm(0.5), cm(0.5), cm(0.5), cm(0.5)]  # Adjust radius for rounded corners

            # # Fit Image works the best tbh, but we`ll see
            # FitImage:
            #     source: "https://img.freepik.com/premium-photo/police-station-vector-icon-illustration-building-landmark-icon-concept-white-isolated-flat-cartoon-style-suitable-web-landing-page-banner-sticker-background_839035-1495604.jpg"
            #     pos_hint: {"top": 1}
            #     radius: (cm(0.3), cm(0.3), cm(0.3), cm(0.3))
                    

        MDBoxLayout:
            orientation: "vertical"
            padding: self.width/20
            spacing: self.width/20
            MDBoxLayout:
                size_hint_y: None
                height: self.minimum_height
                # row_default_height: 200
                # row_force_default: True
                padding: self.width/70
                spacing: self.width/70
                canvas.before:
                    Color:
                        rgba: utils.get_color_from_hex('DBB5B5')  # Set the desired RGBA color
                    RoundedRectangle:
                        size: self.size
                        pos: self.pos
                        radius: [cm(0.3), cm(0.3), cm(0.3), cm(0.3)]  # Optional: rounded corners

                MDButton:
                    id: toggle_slider
                    style: "text"
                    disabled: True
                    size: 0, 0
                    canvas.after:
                        Color:
                            rgba: 0, 0, 0, 0.65
                        BoxShadow:
                            pos: self.pos[0], self.pos[1] - self.height/2
                            size: self.parent.width/2 - 2*self.parent.padding[0], self.parent.height - 2*self.parent.padding[0]
                            offset: 0, -10
                            blur_radius: 25
                            spread_radius: -10, -10
                            border_radius: [cm(0.3), cm(0.3), cm(0.3), cm(0.3)]
                            group: 'slide_rect'
                        Color:
                            rgba: utils.get_color_from_hex('F1E5D1') 
                        RoundedRectangle:
                            pos: self.pos[0], self.pos[1]
                            size: self.parent.width/2 - 2*self.parent.padding[0], self.parent.height - 2*self.parent.padding[0]
                            radius: [cm(0.3), cm(0.3), cm(0.3), cm(0.3)]
                            group: 'slide_rect'

                MDButton:
                    id: login_slider_button
                    style: "text"
                    theme_width: "Custom"
                    width: self.parent.width/2 - 2*self.parent.padding[0]
                    
                    on_release: 
                        root.switch_to_login() if not root.current_active_tab == "login" else None
                    on_press:
                        root.on_toggle('LogIn Button') if not root.current_active_tab == "login" else None

                    MDButtonText:
                        text: "Log In"
                        halign: "center"
                        theme_text_color: "Custom"
                        text_color: utils.get_color_from_hex('493628')
                    
                MDButton:
                    id: signup_slider_button
                    style: "text"
                    theme_width: "Custom"
                    width: self.parent.width/2 - 2*self.parent.padding[0]

                    on_release: 
                        root.switch_to_signup() if not root.current_active_tab == "signup" else None
                    on_press:
                        root.on_toggle('SignUp Button') if not root.current_active_tab == "signup" else None

                    MDButtonText:
                        text: "Sign Up"
                        halign: "center"
                        theme_text_color: "Custom"
                        text_color: utils.get_color_from_hex('493628')
                    

            MDCard:
                id: card
                size_hint: (1, 0.7)
                pos_hint: {"center_x":0.5, "center_y":0.5}
                padding: dp(self.width//20), dp(self.width//10)

                # # Sets custom properties.
                # theme_shadow_color: "Custom"
                # shadow_color: "green"
                theme_bg_color: "Custom"
                md_bg_color: utils.get_color_from_hex('DBB5B5')
                # md_bg_color_disabled: "grey"
                # theme_shadow_offset: "Custom"
                # shadow_offset: (1, -2)
                # theme_shadow_softness: "Custom"
                # shadow_softness: 1
                # theme_elevation_level: "Custom"
                # elevation_level: 5

                MDFloatLayout:
                    id: rotating_box
                    orientation: "vertical"

                    # Signup Fields
                    MDBoxLayout:
                        id: signup_box
                        orientation: "vertical"
                        size_hint: (1,1)
                        pos_hint: {"center_x":0.5, "center_y":0.5}
                        opacity: 0 # Initially hidden   

                        first_name_field: first_name_field
                        last_name_field: last_name_field                     

                        MDLabel:
                            markup: True
                            text: "Lets Get You Started..."
                            adaptive_height: True
                            halign: "left"
                            bold: True
                            theme_font_name: "Custom"
                            font_name: "assets/fonts/Inter_28pt-SemiBold.ttf"
                            theme_font_size: "Custom"
                            font_size: sp(int(self.parent.width//15))
                            theme_text_color: "Custom"
                            text_color: utils.get_color_from_hex('493628')
                            pos_hint: {"center_x":0.5, "center_y":0.95}

                        ColoredMDTextField:
                            id: first_name_field
                            mode: "outlined"
                            radius: [dp(4), dp(4), dp(4), dp(4)]
    
                            pos_hint: {"center_x":0.5, "center_y":0.75}

                            theme_line_color: "Custom"
                            line_color_normal: 0, 0, 0, 0 
                            line_color_focus: utils.get_color_from_hex('987070')

                            canvas.after:
                                Color:
                                    rgba: 1, 1, 1, 0.65
                                BoxShadow:
                                    inset: True
                                    pos: self.pos
                                    size: self.size
                                    offset: 0, -10
                                    blur_radius: 25
                                    spread_radius: -10, -10
                                    border_radius: 10, 10, 10, 10

                            MDTextFieldHintText:
                                text: "First"
                                theme_text_color: "Custom"
                                text_color_normal: utils.get_color_from_hex('987070')
                                text_color_focus: self.text_color_normal



                    # Login Fields
                    MDFloatLayout:
                        id: login_box
                        orientation: "vertical"
                        size_hint: (1,1)
                        pos_hint: {"center_x":0.5, "center_y":0.5}
                        opacity: 1 # Initially visible

                        email_text_field: email_text_field
                        password_text_field: password_text_field

                        MDLabel:
                            markup: True
                            text: "Welcome Back!"
                            adaptive_height: True
                            halign: "left"
                            bold: True
                            theme_font_name: "Custom"
                            font_name: "assets/fonts/Inter_28pt-SemiBold.ttf"
                            theme_font_size: "Custom"
                            font_size: sp(int(self.parent.width//15))
                            theme_text_color: "Custom"
                            text_color: utils.get_color_from_hex('493628')
                            pos_hint: {"center_x":0.5, "center_y":0.95}

                        ColoredMDTextField:
                            id: email_text_field
                            mode: "outlined"
                            validator: "email"
                            radius: [dp(4), dp(4), dp(4), dp(4)]
    
                            error_color: utils.get_color_from_hex('987070')
                            pos_hint: {"center_x":0.5, "center_y":0.75}

                            theme_line_color: "Custom"
                            line_color_normal: 0, 0, 0, 0 
                            line_color_focus: utils.get_color_from_hex('987070')

                            canvas.after:
                                Color:
                                    rgba: 1, 1, 1, 0.65
                                BoxShadow:
                                    inset: True
                                    pos: self.pos
                                    size: self.size
                                    offset: 0, -10
                                    blur_radius: 25
                                    spread_radius: -10, -10
                                    border_radius: 10, 10, 10, 10

                            MDTextFieldLeadingIcon:
                                icon: "account"
                                theme_icon_color: "Custom"
                                icon_color_normal: utils.get_color_from_hex('987070')
                                icon_color_focus: self.icon_color_normal

                            MDTextFieldHintText:
                                text: "Email"
                                theme_text_color: "Custom"
                                text_color_normal: utils.get_color_from_hex('987070')
                                text_color_focus: self.text_color_normal

                            MDTextFieldHelperText:
                                text: "username@domain.com"
                                mode: "on_error"
                                theme_font_size: "Custom"
                                font_size: sp(int(self.parent.width//2))
                
                        MDRelativeLayout:
                            # md_bg_color: "green"
                            size_hint_y: None
                            height: email_text_field.height
                            pos_hint: {"center_x":0.5, "center_y":0.5}

                            ColoredMDTextField:
                                id: password_text_field
                                password: True
                                # required: True
                                radius: [dp(4), dp(4), dp(4), dp(4)]

                                theme_line_color: "Custom"
                                line_color_normal: (0,0,0,0) 
                                line_color_focus: utils.get_color_from_hex('987070')
                                pos_hint: {"center_x":0.5, "center_y":0.5}

                                canvas.after:
                                    Color:
                                        rgba: 1, 1, 1, 0.65
                                    BoxShadow:
                                        inset: True
                                        pos: self.pos
                                        size: self.size
                                        offset: 0, -10
                                        blur_radius: 25
                                        spread_radius: -10, -10
                                        border_radius: 10, 10, 10, 10

                        
                                MDTextFieldLeadingIcon:
                                    icon: "key" 
                                    theme_icon_color: "Custom"
                                    icon_color_normal: utils.get_color_from_hex('987070')
                                    icon_color_focus: self.icon_color_normal

                                MDTextFieldHintText:
                                    text: "Password"
                                    theme_text_color: "Custom"
                                    text_color_normal: utils.get_color_from_hex('987070')
                                    text_color_focus: self.text_color_normal
                                
                            MDIconButton:
                                icon: "eye-lock"
                                style: "standard"
                                theme_icon_color: "Custom"
                                icon_color: utils.get_color_from_hex('987070')
                                pos_hint: {"center_x": .92, "center_y": .5}
                                on_press:
                                    password_text_field.password = True if self.icon == "eye" else False
                                on_release:
                                    self.icon = "eye" if self.icon == "eye-lock" else "eye-lock"
                                    
                        MDButton:
                            style: "elevated"
                            theme_width: "Custom"
                            theme_height: "Custom"
                            size_hint_x: .6
                            size_hint_y: .12
                            theme_bg_color: "Custom"
                            md_bg_color: utils.get_color_from_hex('493628')
                            pos_hint: {"center_x": .5, "center_y": .3}

                            MDButtonText:
                                text: "Login"
                                theme_font_name: "Custom"
                                font_name: "assets/fonts/Inter_28pt-SemiBold.ttf"
                                theme_font_size: "Custom"
                                font_size: sp(int(self.parent.width//15))
                                theme_text_color: "Custom"
                                text_color: utils.get_color_from_hex('F1E5D1')
                                pos_hint: {"center_x": .5, "center_y": .5}

                        MDDivider:
                            id: login_divider
                            color: utils.get_color_from_hex('493628')
                            divider_width: dp(2)
                            size_hint_x: 1
                            pos_hint: {'center_x': .5, 'center_y': .2}
                            opacity: .1

                        MDLabel:
                            text: "or"
                            halign: "center"
                            adaptive_height: True
                            theme_width: "Custom"
                            size_hint_x: 0.1
                            bold: True
                            theme_font_name: "Custom"
                            font_name: "assets/fonts/Inter_28pt-SemiBold.ttf"
                            # theme_font_size: "Custom"
                            # font_size: sp(int(self.parent.width//15))
                            theme_bg_color: "Custom"
                            md_bg_color: utils.get_color_from_hex('DBB5B5')
                            theme_text_color: "Custom"
                            text_color: [value  if value != 1.0 else value*.3 for value in utils.get_color_from_hex('493628')]
                            pos_hint: login_divider.pos_hint
                        
                        MDGridLayout:
                            cols: 3
                            size_hint_y: None
                            height: self.minimum_height
                            size_hint_x: 1
                            pos_hint: {"center_x": .5, "center_y": .05}
                            spacing: self.width//10
                            padding: self.width//5, 0

                            MDIconButton:
                                icon: "google"
                                style: "outlined"
                                theme_font_size: "Custom"
                                font_size: sp(self.parent.width//12)
                                size_hint_x: self.parent.width//10
                                size_hint_y: None
                                height: self.width
                                theme_text_color: "Custom"
                                text_color: utils.get_color_from_hex('493628')
                                theme_line_color: "Custom"
                                line_color: utils.get_color_from_hex('987070')

                            MDIconButton:
                                icon: "facebook"
                                style: "outlined"
                                theme_font_size: "Custom"
                                font_size: sp(self.parent.width//12)
                                size_hint_x: self.parent.width//10
                                size_hint_y: None
                                height: self.width
                                theme_text_color: "Custom"
                                text_color: utils.get_color_from_hex('493628')
                                theme_line_color: "Custom"
                                line_color: utils.get_color_from_hex('987070')

                            MDIconButton:
                                icon: "twitter"
                                style: "outlined"
                                theme_font_size: "Custom"
                                font_size: sp(self.parent.width//12)
                                size_hint_x: self.parent.width//10
                                size_hint_y: None
                                height: self.width
                                theme_text_color: "Custom"
                                text_color: utils.get_color_from_hex('493628')
                                theme_line_color: "Custom"
                                line_color: utils.get_color_from_hex('987070')
    
    MDFloatLayout:
        AsyncImage:
            source: "assets/loginMascot.gif"
            size_hint: (0.40, 0.6)
            pos_hint: {"center_x":0.35, "center_y":0.5}

<ColoredMDTextField@MDTextField>
    canvas.after:
        Color:
            rgba: [value if value != 1.0 else value*.3 for value in utils.get_color_from_hex('F1E5D1')]
        RoundedRectangle:
            # source: 'assets/loginBackground.jpeg'
            size: self.size
            pos: self.pos
            # radius: [cm(0.5), cm(0.5), cm(0.5), cm(0.5)]  # Adjust radius for rounded corners
"""


class ColoredMDTextField(MDTextField):
    # def set_pos_hint_text(self, y: float, x: float) -> None:
    #     """Animates the x-axis width and y-axis height of the hint text."""
    #     print(self.text)
    #     if self.text == "":
    #         Animation(_hint_y=y, _hint_x=x, d=0.2, t="out_quad").start(self)
    #     else:
    #         Animation(_hint_y=y-dp(10), _hint_x=x, d=0.2, t="out_quad").start(self)

    """
    A lot of stuff is possible to change here
    refer: https://github.com/kivymd/KivyMD/blob/master/kivymd/uix/textfield/textfield.py
    """
    pass

class MyScreen(MDScreen):
    def __init__(self, **kwargs):
        Builder.load_string(MS)
        super().__init__(**kwargs)
        

class ScreenLayout(MDFloatLayout):
    current_active_tab = "login"
    def __init__(self, **kwargs):
        Builder.load_string(SL)
        super().__init__(**kwargs)

    def on_toggle(self, value):
        if value == 'LogIn Button':
            anim_move_to = self.ids.login_slider_button.pos
        elif value == 'SignUp Button':
            anim_move_to = self.ids.signup_slider_button.pos
        anim = Animation(pos=anim_move_to, duration=0.3)
        anim.start(self.ids.toggle_slider.canvas.after.get_group('slide_rect')[0])
        anim.start(self.ids.toggle_slider.canvas.after.get_group('slide_rect')[1])

    def switch_to_login(self):
        if not self.current_active_tab == 'login':
            self.current_active_tab = 'login'
            self.animate_card('login')

    def switch_to_signup(self):
        if not self.current_active_tab == 'signup':
            self.current_active_tab = 'signup'
            self.animate_card('signup')

    def animate_card(self, mode):
        card = self.ids.card
        login_email_field = self.ids.login_box.email_text_field
        login_password_field = self.ids.login_box.password_text_field

        # Animations for  rotation on Y-Axis (CSS-like flip)
        animation1 = Animation(size_hint_x=0, duration=0.3, t='linear') # Shrink the card horizontally
        animation2 = Animation(size_hint_x=1, duration=0.3, t='linear') # Expand the card back horizontally

        # Function to turn opacity of hint_text and helper_text 0 and 1 on changing sides
        def change_text_field_elements_opacity(field_list, opacity):
            for field_name in field_list:
                # Hint text label opacity
                field_name.set_texture_color(
                    field_name._hint_text_label,
                    field_name.canvas.after.get_group("hint-text-color")[0],
                    (
                        field_name.theme_cls.primaryColor
                        if not field_name._hint_text_label.text_color_focus
                        else field_name._hint_text_label.text_color_focus[:3] + [opacity]
                    )
                    if not field_name.error
                    else field_name._get_error_color()[:3] + [opacity],
                )
                field_name._hint_text_label.texture_update()

                # Helper text label opacity
                if field_name._helper_text_label:
                    field_name.set_texture_color(
                        field_name._helper_text_label,
                        field_name.canvas.before.get_group("helper-text-color")[0],
                        (
                            field_name.theme_cls.onSurfaceVariantColor
                            if not field_name._helper_text_label.text_color_normal
                            else field_name._helper_text_label.text_color_normal[:3] + [opacity]
                        )
                        if not field_name.error
                        else field_name._get_error_color()[:3] + [opacity],
                    )
                    field_name._helper_text_label.texture_update()
            
        # Determine which box (login or signup) to show after animation1 completes
        if mode == 'login':
            animation1.bind(on_complete=lambda *args: self.show_login_card())
            animation2.bind(on_complete=lambda *args: change_text_field_elements_opacity([login_email_field, login_password_field], 1))
        else:    
            animation1.bind(on_start=lambda *args: change_text_field_elements_opacity([login_email_field, login_password_field], 0))
            animation1.bind(on_complete=lambda *args: self.show_signup_card())

        # Play both animations in sequence (shrink then expand with the new content)
        animation1.start(card)
        animation1.bind(on_complete=lambda *args: animation2.start(card))
    
    def show_login_card(self):
        self.ids.signup_box_email_field.disabled = True
        self.ids.login_box.opacity = 1
        self.ids.signup_box.opacity = 0

    def show_signup_card(self):
        self.ids.signup_box_email_field.disabled = False
        self.ids.login_box.opacity = 0
        self.ids.signup_box.opacity = 1
